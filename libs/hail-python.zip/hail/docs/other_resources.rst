.. _sec-other-resources:

===============
Other Resources
===============

.. toctree::
    :maxdepth: 2
 
    Hadoop Glob Patterns <hadoop_glob_patterns>
    SQL <sql>

