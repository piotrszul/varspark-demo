.. DANGER::

    This method is *experimental*. We neither guarantee interface 
    stability nor that the results are viable for any particular use.

